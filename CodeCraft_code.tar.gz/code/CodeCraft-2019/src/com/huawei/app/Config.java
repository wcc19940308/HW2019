package com.huawei.app;

public class Config {
    public static int carNumber = 3000;
}
